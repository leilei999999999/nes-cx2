/*****************************************************************************
 *
 *  XVID MPEG-4 VIDEO CODEC
 *  - Aligned Memory Allocator -
 *
 *  Copyright(C) 2002-2003 Edouard Gomez <ed.gomez@free.fr>
 *
 *  This program is free software ; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation ; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY ; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program ; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
 *
 * $Id: mem_align.c 1985 2011-05-18 09:02:35Z Isibaar $
 *
 ****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include "mem_align.h"

/* SRAM Context */
static uint8_t *sram_pool_base = NULL;
static unsigned int sram_pool_size = 0;
static unsigned int sram_pool_usage = 0;

#if defined(NDVIDEO_BUILD_MPEG4_MODULE) && NDVIDEO_BUILD_MPEG4_MODULE
/* Global tables normally live for the process lifetime. A module owns their
 * heap fallbacks and must release them before its static pointers disappear.
 * Tracking is active only during shared-table initialization, never on the
 * frame decode path. */
static void *module_globals[64];
static unsigned module_global_count;
static int module_tracking, module_tracking_overflow;
int xvid_module_track_globals(int enabled)
{ int previous = module_tracking; module_tracking = enabled; return previous; }
static void *track_global(void *pointer)
{
    if (pointer && module_tracking) {
        if (module_global_count < sizeof(module_globals)/sizeof(module_globals[0]))
            module_globals[module_global_count++] = pointer;
        else
            module_tracking_overflow = 1;
    }
    return pointer;
}
static void forget_global(void *pointer)
{
    unsigned i;
    for (i = 0; i < module_global_count; ++i) {
        if (module_globals[i] == pointer) {
            module_globals[i] = module_globals[--module_global_count];
            break;
        }
    }
}
int xvid_module_release_globals(void)
{
    /* Refuse unload if a future table expansion exceeds the bounded registry. */
    if (module_tracking || module_tracking_overflow) return 0;
    while (module_global_count) xvid_free(module_globals[module_global_count - 1]);
    xvid_init_sram(NULL, 0);
    return 1;
}
#else
#define track_global(pointer) (pointer)
#define forget_global(pointer) ((void)0)
#endif

/*****************************************************************************
 * xvid_malloc
 *
 * This function allocates 'size' bytes (usable by the user) on the heap and
 * takes care of the requested 'alignment'.
 * In order to align the allocated memory block, the xvid_malloc allocates
 * 'size' bytes + 'alignment' bytes. So try to keep alignment very small
 * when allocating small pieces of memory.
 *
 * NB : a block allocated by xvid_malloc _must_ be freed with xvid_free
 *      (the libc free will return an error)
 *
 * Returned value : - NULL on error
 *                  - Pointer to the allocated aligned block
 *
 ****************************************************************************/

void *
xvid_malloc(size_t size,
			uint8_t alignment)
{
	uint8_t *mem_ptr;

	if (!alignment) {

		/* We have not to satisfy any alignment */
		if ((mem_ptr = (uint8_t *) malloc(size + 1)) != NULL) {

			/* Store (mem_ptr - "real allocated memory") in *(mem_ptr-1) */
			*mem_ptr = (uint8_t)1;

			/* Return the mem_ptr pointer */
			return track_global((void *)(mem_ptr+1));
		}
	} else {
		uint8_t *tmp;

		/* Allocate the required size memory + alignment so we
		 * can realign the data if necessary */
		if ((tmp = (uint8_t *) malloc(size + alignment)) != NULL) {

			/* Align the tmp pointer */
			mem_ptr =
				(uint8_t *) ((ptr_t) (tmp + alignment - 1) &
							 (~(ptr_t) (alignment - 1)));

			/* Special case where malloc have already satisfied the alignment
			 * We must add alignment to mem_ptr because we must store
			 * (mem_ptr - tmp) in *(mem_ptr-1)
			 * If we do not add alignment to mem_ptr then *(mem_ptr-1) points
			 * to a forbidden memory space */
			if (mem_ptr == tmp)
				mem_ptr += alignment;

			/* (mem_ptr - tmp) is stored in *(mem_ptr-1) so we are able to retrieve
			 * the real malloc block allocated and free it in xvid_free */
			*(mem_ptr - 1) = (uint8_t) (mem_ptr - tmp);

			/* Return the aligned pointer */
			return track_global((void *)mem_ptr);
		}
	}

	return(NULL);
}

/*****************************************************************************
 * xvid_free
 *
 * Free a previously 'xvid_malloc' allocated block. Does not free NULL
 * references.
 *
 * Returned value : None.
 *
 ****************************************************************************/

void
xvid_free(void *mem_ptr)
{

	uint8_t *ptr;

	if (mem_ptr == NULL)
		return;

	/* If pointer is in SRAM pool, do nothing (it's persistent/bump allocated) */
	if (sram_pool_base && 
		(uint8_t*)mem_ptr >= sram_pool_base && 
		(uint8_t*)mem_ptr < (sram_pool_base + sram_pool_size)) {
		return;
	}

	/* Aligned pointer */
	forget_global(mem_ptr);
	ptr = mem_ptr;

	/* *(ptr - 1) holds the offset to the real allocated block
	 * we sub that offset os we free the real pointer */
	ptr -= *(ptr - 1);

	/* Free the memory */
	free(ptr);
}



void
xvid_init_sram(void *base, unsigned int size)
{
	sram_pool_base = (uint8_t*)base;
	sram_pool_size = size;
	sram_pool_usage = 0;
}

void *
xvid_malloc_sram(size_t size, uint8_t alignment)
{
	uint8_t *ptr = NULL;
	uintptr_t aligned_usage;
	uintptr_t aligned_addr;

	if (!sram_pool_base) {
		return xvid_malloc(size, alignment);
	}

	/* calculate alignment adjustment */
	if (alignment == 0) alignment = 1;

	/* current pointer */
	aligned_addr = (uintptr_t)(sram_pool_base + sram_pool_usage);

	/* align up */
	if (alignment > 1) {
		uintptr_t mask = alignment - 1;
		if (aligned_addr & mask) {
			aligned_addr = (aligned_addr + mask) & ~mask;
		}
	}

	/* check overflow */
	if ((aligned_addr + size) <= ((uintptr_t)sram_pool_base + sram_pool_size)) {
		ptr = (uint8_t*)aligned_addr;
		sram_pool_usage = (aligned_addr + size) - (uintptr_t)sram_pool_base;
		return (void*)ptr;
	}

	/* Fallback to SDRAM if SRAM full */
	return xvid_malloc(size, alignment);
}
